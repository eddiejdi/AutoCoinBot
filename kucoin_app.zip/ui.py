# ui.py — VERSÃO COM AUTO-RESTART
import streamlit as st
import os
import subprocess
import signal
import time
import json
import pandas as pd
from pathlib import Path
from collections import deque
import fcntl
import errno
import sys
import shlex

ROOT = Path(__file__).resolve().parent
HISTORY_JSON = ROOT / "bot_history.json"
PROC_BUFFER_MAX_CHARS = 50000

PROCS = {}
PROC_BUFFERS = {}

# ---------------------------------------------------------
#                   UTILITÁRIOS
# ---------------------------------------------------------
def _read_history_df():
    if HISTORY_JSON.exists():
        try:
            data = json.loads(HISTORY_JSON.read_text(encoding="utf-8"))
            return pd.json_normalize(data)
        except:
            pass
    return pd.DataFrame()

# ---------------------------------------------------------
#   SELETOR DE PYTHON CORRIGIDO
# ---------------------------------------------------------
def _choose_python_executable():
    """Encontra Python válido no sistema"""
    candidates = [
        sys.executable,
        str(ROOT / "venv/bin/python3"),
        str(ROOT / "venv/bin/python"),
        str(ROOT.parent / "venv/bin/python3"),
        "/usr/bin/python3",
        "/usr/local/bin/python3",
        "python3",
        "python",
    ]

    for path in candidates:
        path = path.replace("venv./", "venv/")
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
    
    return "python3"

# ---------------------------------------------------------
#              START DO BOT - COM AUTO-RESTART
# ---------------------------------------------------------
def _start_process(key, symbol, entry_price, mode, targets_str,
                   trailing, stop_loss, size, funds, interval, dry_run, 
                   verbose, auto_restart, max_cycles):

    python_bin = _choose_python_executable()

    cmd = [
        python_bin, 
        "-u",
        str(ROOT / "bot_core.py"),
        "--symbol", symbol,
        "--entry", str(entry_price),
        "--mode", mode,
        "--targets", targets_str,
        "--interval", str(interval),
        "--size", str(size),
        "--funds", str(funds),
    ]
    
    if trailing:
        cmd.extend(["--trailing", str(trailing)])
    if stop_loss:
        cmd.extend(["--stoploss", str(stop_loss)])
    
    if dry_run:
        cmd.append("--dry")
    else:
        cmd.append("--no-dry")

    if verbose:
        cmd.append("--verbose")
    
    if auto_restart:
        cmd.append("--auto-restart")
    
    if max_cycles > 0:
        cmd.extend(["--max-cycles", str(max_cycles)])

    cmd_repr = " ".join(shlex.quote(c) for c in cmd)

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=False,
            bufsize=0,
            cwd=str(ROOT),
            preexec_fn=os.setsid,
            env=env,
            close_fds=True,
        )
    except Exception as e:
        PROC_BUFFERS.setdefault(key, deque()).append(
            f"[ERRO START] {e}\nCMD: {cmd_repr}\nPython: {python_bin}\n"
        )
        return None

    PROCS[key] = proc
    PROC_BUFFERS[key] = deque()
    PROC_BUFFERS[key].append(f"[STARTED] PID={proc.pid}\nCMD: {cmd_repr}\n\n")

    return proc

# ---------------------------------------------------------
#                     STOP DO BOT
# ---------------------------------------------------------
def _stop_process(key):
    proc = PROCS.get(key)
    if not proc:
        return
    
    try:
        os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
    except:
        try:
            proc.terminate()
        except:
            pass

    try:
        proc.wait(timeout=3)
    except:
        try:
            proc.kill()
        except:
            pass

    PROCS.pop(key, None)

# ---------------------------------------------------------
#         LEITURA NÃO-BLOQUEANTE
# ---------------------------------------------------------
def _nonblocking_read_from_proc(proc):
    if not proc or not proc.stdout:
        return ""

    fd = proc.stdout.fileno()
    
    try:
        flags = fcntl.fcntl(fd, fcntl.F_GETFL)
        fcntl.fcntl(fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)
    except:
        pass

    try:
        data = os.read(fd, 8192)
        if not data:
            return ""
        return data.decode("utf-8", errors="replace")
    except OSError as e:
        if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
            return ""
        return ""
    except:
        return ""

def _append_to_proc_buffer(key, text):
    if key not in PROC_BUFFERS:
        PROC_BUFFERS[key] = deque()

    for line in text.splitlines(keepends=True):
        if len(line) > 5000:
            line = line[-5000:] + "\n[...truncated]\n"
        PROC_BUFFERS[key].append(line)

    total = sum(len(x) for x in PROC_BUFFERS[key])
    while total > PROC_BUFFER_MAX_CHARS and PROC_BUFFERS[key]:
        total -= len(PROC_BUFFERS[key].popleft())

def _get_proc_buffer_text(key):
    if key not in PROC_BUFFERS:
        return ""
    return "".join(list(PROC_BUFFERS[key]))

# ---------------------------------------------------------
#              PARSE DE EVENTOS JSON
# ---------------------------------------------------------
def _extract_json_events(text: str) -> list:
    events = []
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("{") and line.endswith("}"):
            try:
                events.append(json.loads(line))
            except:
                pass
    return events

# ---------------------------------------------------------
#              ESTATÍSTICAS DO BOT
# ---------------------------------------------------------
def _calculate_bot_stats(events: list) -> dict:
    """Calcula estatísticas do bot baseado nos eventos"""
    stats = {
        "current_cycle": 0,
        "total_cycles_completed": 0,
        "targets_executed": 0,
        "total_targets": 0,
        "total_profit": 0.0,
        "last_price": 0.0,
        "entry_price": 0.0,
        "status": "running"
    }
    
    for event in events:
        if event.get("event") == "bot_initialized":
            stats["entry_price"] = event.get("entry_price", 0)
            stats["total_targets"] = len(event.get("targets", []))
        
        elif event.get("event") == "cycle_started":
            stats["current_cycle"] = event.get("cycle_number", 0)
        
        elif event.get("event") == "price_check":
            stats["last_price"] = event.get("price", 0)
            targets_str = event.get("executed_targets", "0/0")
            if "/" in targets_str:
                executed, total = targets_str.split("/")
                stats["targets_executed"] = int(executed)
        
        elif event.get("event") == "trade_executed":
            stats["total_profit"] += event.get("profit_usdt", 0)
        
        elif event.get("event") == "cycle_finished":
            stats["total_cycles_completed"] = event.get("total_cycles_completed", 0)
        
        elif event.get("event") == "bot_finalized":
            stats["status"] = "stopped"
            stats["total_profit"] = event.get("total_profit_usdt", stats["total_profit"])
    
    return stats

# ---------------------------------------------------------
#                   INTERFACE STREAMLIT
# ---------------------------------------------------------
def render_bot_control():
    st.set_page_config(layout="wide", page_title="KuCoin PRO — Bot Controller")

    st.title("🤖 KuCoin PRO — Bot Controller")
    st.caption(f"Python: `{sys.executable}`")

    if "active_bots" not in st.session_state:
        st.session_state.active_bots = []

    # ------------------------ SIDEBAR ------------------------
    with st.sidebar:
        st.header("⚙️ Configurações")

        with st.form("bot_config"):
            symbol = st.text_input("Symbol", "BTC-USDT")
            entry_price = st.number_input("Entry Price", value=88000.0, step=100.0)
            
            col1, col2 = st.columns(2)
            with col1:
                mode = st.selectbox("Mode", ["sell", "buy", "both", "reverse"])
            with col2:
                interval = st.number_input("Interval (s)", value=5.0, step=1.0)
            
            targets_str = st.text_input("Targets (pct:portion)", "1:0.3,3:0.5,5:0.2")
            
            col3, col4 = st.columns(2)
            with col3:
                trailing = st.number_input("Trailing %", value=0.0, step=0.5)
            with col4:
                stop_loss = st.number_input("Stop Loss %", value=0.0, step=0.5)
            
            col5, col6 = st.columns(2)
            with col5:
                size = st.number_input("Size", value=0.001, format="%.6f")
            with col6:
                funds = st.number_input("Funds (USDT)", value=100.0, step=10.0)
            
            st.divider()
            
            dry_run = st.checkbox("Dry Run (Simulação)", value=True)
            
            if not dry_run:
                st.error("⚠️ ATENÇÃO: Modo REAL ativado! Ordens serão executadas na API da KuCoin com dinheiro real!")
                confirm = st.checkbox("✅ Confirmo que quero operar com dinheiro REAL", value=False)
                if not confirm:
                    st.warning("Marque a confirmação acima para habilitar ordens reais")
                    dry_run = True  # Força dry_run se não confirmou
            
            verbose = st.checkbox("Verbose Logs", value=False)
            
            st.markdown("### 🔄 Auto-Restart")
            auto_restart = st.checkbox("Reiniciar Automaticamente", value=False,
                                      help="Reinicia o bot automaticamente após completar todos os targets")
            max_cycles = st.number_input("Ciclos Máximos", value=0, step=1,
                                        help="0 = ilimitado. Define quantos ciclos executar antes de parar")
            
            submit = st.form_submit_button("🚀 START BOT", use_container_width=True)
            
            if submit:
                key = f"bot_{int(time.time())}"
                proc = _start_process(
                    key, symbol, entry_price, mode, targets_str,
                    trailing if trailing > 0 else None,
                    stop_loss if stop_loss != 0 else None,
                    size, funds, interval, dry_run, verbose,
                    auto_restart, max_cycles
                )
                if proc:
                    st.session_state.active_bots.append(key)
                    
                    if dry_run:
                        st.success(f"✅ Bot iniciado em SIMULAÇÃO: `{key}`")
                    else:
                        st.error(f"🔴 Bot iniciado em MODO REAL: `{key}`")
                        st.warning("⚠️ ORDENS REAIS SERÃO EXECUTADAS NA KUCOIN!")
                    
                    if auto_restart:
                        st.info(f"🔄 Auto-restart ativado {'(ilimitado)' if max_cycles == 0 else f'({max_cycles} ciclos)'}")
                else:
                    st.error("❌ Erro ao iniciar bot")

        st.divider()
        
        if st.button("🗑️ Limpar Bots Inativos", use_container_width=True):
            active = []
            for key in st.session_state.active_bots:
                proc = PROCS.get(key)
                if proc and proc.poll() is None:
                    active.append(key)
                else:
                    PROC_BUFFERS.pop(key, None)
            st.session_state.active_bots = active
            st.rerun()

    # ------------------------ BOT STATUS ------------------------
    st.subheader("📊 Bots Ativos")
    
    if not st.session_state.active_bots:
        st.info("Nenhum bot rodando. Configure e inicie um bot no painel lateral.")
    else:
        for idx, key in enumerate(list(st.session_state.active_bots)):
            proc = PROCS.get(key)
            running = proc and proc.poll() is None
            
            # Atualiza logs
            if proc:
                new_data = _nonblocking_read_from_proc(proc)
                if new_data:
                    _append_to_proc_buffer(key, new_data)
            
            # Extrai eventos e calcula stats
            log_text = _get_proc_buffer_text(key)
            events = _extract_json_events(log_text)
            stats = _calculate_bot_stats(events)
            
            # Verifica se está em modo real
            is_real_mode = False
            for event in events:
                if event.get("event") == "bot_initialized":
                    is_real_mode = not event.get("dry_run", True)
                    break
            
            mode_indicator = "🔴 REAL" if is_real_mode else "🟡 SIM"
            
            with st.expander(f"{'🟢' if running else '⚫'} {mode_indicator} {key} — Ciclo {stats['current_cycle']}", expanded=running):
                # Métricas principais
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("Status", "Running" if running else "Stopped")
                with col2:
                    st.metric("Ciclo Atual", stats['current_cycle'])
                with col3:
                    st.metric("Targets", f"{stats['targets_executed']}/{stats['total_targets']}")
                with col4:
                    profit_color = "normal" if stats['total_profit'] >= 0 else "inverse"
                    st.metric("Profit (USDT)", f"{stats['total_profit']:.2f}", 
                             delta_color=profit_color)
                
                col5, col6, col7, col8 = st.columns(4)
                with col5:
                    st.metric("Ciclos Completados", stats['total_cycles_completed'])
                with col6:
                    st.metric("Entry Price", f"{stats['entry_price']:.2f}")
                with col7:
                    st.metric("Last Price", f"{stats['last_price']:.2f}")
                with col8:
                    if proc:
                        st.metric("PID", proc.pid)
                    if st.button("⏹️ STOP", key=f"stop_{key}", use_container_width=True):
                        _stop_process(key)
                        st.session_state.active_bots.remove(key)
                        st.success(f"Bot parado: {key}")
                        st.rerun()

                # Exibe logs
                st.markdown("### 📜 Logs")
                
                if not log_text.strip():
                    st.info("Aguardando logs do bot...")
                    continue

                if events:
                    # Últimos 30 eventos
                    for event in events[-30:]:
                        event_type = event.get("event", "unknown")
                        cycle = event.get("cycle", 0)
                        
                        # Remove campos redundantes
                        display = {k: v for k, v in event.items() 
                                  if k not in ["timestamp", "bot_id", "cycle"]}
                        
                        # Coloração por tipo de evento
                        if "error" in event_type:
                            st.error(f"**[Ciclo {cycle}] {event_type}**")
                            st.json(display)
                        elif "executed" in event_type or "triggered" in event_type or "hit" in event_type:
                            st.success(f"**[Ciclo {cycle}] {event_type}**")
                            st.json(display)
                        elif "started" in event_type or "initialized" in event_type or "reset" in event_type:
                            st.info(f"**[Ciclo {cycle}] {event_type}**")
                            st.json(display)
                        elif "restarting" in event_type:
                            st.warning(f"**[Ciclo {cycle}] {event_type}**")
                            st.json(display)
                        else:
                            with st.chat_message("assistant"):
                                st.markdown(f"**[Ciclo {cycle}] {event_type}**")
                                st.json(display)
                else:
                    st.code(log_text[-5000:], language="text")

    # ------------------------ HISTÓRICO ------------------------
    st.divider()
    st.subheader("📋 Histórico de Execuções")
    
    df = _read_history_df()
    if not df.empty:
        display_cols = [c for c in df.columns 
                       if c in ["id", "symbol", "mode", "total_cycles_completed",
                               "total_profit", "final_status", "end_ts", "auto_restart"]]
        if display_cols:
            st.dataframe(df[display_cols].tail(10), use_container_width=True)
    else:
        st.info("Nenhum histórico disponível ainda.")

    # Auto-refresh a cada 2 segundos
    time.sleep(2)
    st.rerun()

# ---------------------------------------------------------
if __name__ == "__main__":
    render_bot_control()
