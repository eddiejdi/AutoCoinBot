# bot_core.py — VERSÃO CORRIGIDA (Bot NÃO encerra após trades)
from __future__ import annotations
import time
import json
import uuid
import threading
import os
import sys
import logging
import logging.handlers
from pathlib import Path
from typing import List, Tuple, Optional

# Tenta importar a API
try:
    from . import api
except Exception as e:
    print(f"[INFO] API não encontrada: {e}", file=sys.stderr, flush=True)
    print("[INFO] Rodando em SIMULAÇÃO TOTAL", file=sys.stderr, flush=True)
    HAS_REAL_API = False
    api = None

ROOT = Path(__file__).resolve().parent
HISTORY_JSON = ROOT / "bot_history.json"
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

# ====================== LOGGER CORRIGIDO ======================
def setup_bot_logger(bot_id: str) -> logging.Logger:
    """Logger que imprime JSON puro no STDOUT para ui.py capturar"""
    logger = logging.getLogger(f"bot_{bot_id}")
    if logger.handlers:
        return logger
    
    logger.setLevel(logging.INFO)
    logger.propagate = False
    
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setLevel(logging.INFO)
    
    class JSONFormatter(logging.Formatter):
        def format(self, record):
            return record.getMessage()
    
    stdout_handler.setFormatter(JSONFormatter())
    logger.addHandler(stdout_handler)
    
    try:
        file_handler = logging.handlers.RotatingFileHandler(
            LOG_DIR / f"bot_{bot_id}.log",
            maxBytes=5*1024*1024,
            backupCount=3,
            encoding="utf-8"
        )
        file_handler.setFormatter(JSONFormatter())
        logger.addHandler(file_handler)
    except Exception as e:
        print(f"[WARN] Não foi possível criar arquivo de log: {e}", file=sys.stderr, flush=True)
    
    return logger

# ====================== HISTÓRICO ======================
def _append_history(entry: dict):
    hist = []
    if HISTORY_JSON.exists():
        try:
            hist = json.loads(HISTORY_JSON.read_text(encoding="utf-8"))
        except:
            pass
    hist.append(entry)
    try:
        HISTORY_JSON.write_text(json.dumps(hist, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        print(f"[ERROR] Salvando histórico: {e}", file=sys.stderr, flush=True)

# ====================== ORDEM SIMULADA ======================
def place_market_order(symbol: str, side: str, funds: Optional[float] = None,
                       size: Optional[float] = None, dry_run: bool = True,
                       logger: Optional[logging.Logger] = None) -> dict:
    payload = {
        "clientOid": str(uuid.uuid4()),
        "side": side,
        "symbol": symbol,
        "type": "market",
    }
    if funds: 
        payload["funds"] = str(round(funds, 8))
    if size: 
        payload["size"] = str(round(size, 12))

    if dry_run:
        sim = {
            "simulated": True,
            "clientOid": payload["clientOid"],
            "side": side,
            "symbol": symbol,
            "funds": payload.get("funds"),
            "size": payload.get("size"),
            "timestamp": int(time.time() * 1000)
        }
        if logger:
            logger.info(json.dumps({
                "event": "simulated_order", 
                "payload": payload,
                "result": "success"
            }))
        return sim

    # Ordem real (se tiver API)
    try:
        import requests
        endpoint = "/api/v1/orders"
        url = api._base_url() + endpoint
        body_str = json.dumps(payload, separators=(",", ":"))
        headers = api._build_headers("POST", endpoint, body_str)
        r = requests.post(url, headers=headers, data=body_str, timeout=20)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        if logger:
            logger.error(json.dumps({"event": "order_error", "error": str(e)}))
        return {"error": str(e)}

# ====================== BOT PRINCIPAL ======================
class EnhancedTradeBot:
    def __init__(self, symbol: str, entry_price: float, mode: str = "sell",
                 targets: Optional[List[Tuple[float, float]]] = None,
                 trailing_stop_pct: Optional[float] = None,
                 stop_loss_pct: Optional[float] = None,
                 size: Optional[float] = None, funds: Optional[float] = None,
                 check_interval: float = 5.0, dry_run: bool = True,
                 verbose: bool = False):

        self.symbol = symbol.upper()
        self.entry_price = float(entry_price)
        self.mode = mode.lower()
        self.targets = sorted(targets or [], key=lambda x: x[0])
        self.trailing_stop_pct = trailing_stop_pct
        self.stop_loss_pct = stop_loss_pct
        self.size = size
        self.funds = funds
        self.check_interval = check_interval
        self.dry_run = dry_run or not HAS_REAL_API

        self._id = str(uuid.uuid4())[:8]
        self._logger = setup_bot_logger(self._id)
        self._stopped = threading.Event()
        self._start_ts = time.time()
        self._last_price = entry_price
        self._peak_price = entry_price
        self._valley_price = entry_price
        self._executed_parts: List[float] = []
        self._remaining_fraction = 1.0
        
        # Calcula fração restante considerando targets
        for _, portion in self.targets:
            self._remaining_fraction -= portion
        
        self.executed_trades: List[dict] = []

        self._log("bot_initialized", 
                  symbol=self.symbol, 
                  entry_price=self.entry_price,
                  mode=self.mode, 
                  targets=self.targets,
                  initial_remaining_fraction=round(self._remaining_fraction, 4),
                  dry_run=self.dry_run,
                  has_api=HAS_REAL_API)

    def _log(self, event: str, **kwargs):
        """Log estruturado em JSON puro para STDOUT"""
        log_entry = {
            "bot_id": self._id,
            "event": event,
            "timestamp": time.time(),
            **kwargs
        }
        message = json.dumps(log_entry, ensure_ascii=False, default=str)
        self._logger.info(message)
        sys.stdout.flush()

    def _get_current_price(self) -> float:
        """Simula preço crescente RÁPIDO para testes"""
        if not HAS_REAL_API or self.dry_run:
            elapsed = time.time() - self._start_ts
            # 10% de crescimento em 30 segundos
            simulated = self.entry_price * (1 + (elapsed / 30) * 0.1)
            self._log("price_simulated", 
                     price=round(simulated, 2), 
                     elapsed=round(elapsed, 1),
                     growth_pct=round(((simulated / self.entry_price) - 1) * 100, 2))
            return simulated
        
        try:
            p = api.get_orderbook_price(self.symbol)
            return float(p) if p else self._last_price
        except Exception as e:
            self._log("price_fetch_error", error=str(e))
            return self._last_price

    def _calculate_portion_size(self, portion: float) -> float:
        if self.size: 
            return self.size * portion
        price = self._get_current_price()
        if self.funds and price: 
            return (self.funds * portion) / price
        return 0.0

    def _execute_fraction(self, portion: float, side: str):
        size = self._calculate_portion_size(portion)
        self._log("executing_order", side=side, portion=portion, size=size)
        result = place_market_order(
            self.symbol, side, size=size, 
            dry_run=self.dry_run, logger=self._logger
        )
        return result

    def _record_trade(self, kind: str, price: float, portion: float):
        profit = 0
        if "sell" in kind and self.size:
            profit = portion * (price - self.entry_price) * self.size
        elif "buy" in kind and self.size:
            profit = portion * (self.entry_price - price) * self.size

        trade = {
            "timestamp": time.time(),
            "kind": kind,
            "price": round(price, 2),
            "portion": round(portion, 4),
            "profit_usdt": round(profit, 2),
            "simulated": self.dry_run
        }
        self.executed_trades.append(trade)
        self._log("trade_executed", **trade)

    def _should_continue(self) -> bool:
        """Verifica se o bot deve continuar executando"""
        # Se foi parado manualmente
        if self._stopped.is_set():
            return False
        
        # Se ainda tem targets para executar
        if len(self._executed_parts) < len(self.targets):
            return True
        
        # Se tem fração restante significativa (para trailing/stop loss)
        if self._remaining_fraction > 0.01:
            return True
        
        return False

    def start(self):
        """Loop principal do bot"""
        self._log("bot_started", 
                 message="Iniciando monitoramento...",
                 total_targets=len(self.targets))
        
        try:
            cycle = 0
            while self._should_continue():
                cycle += 1
                price = self._get_current_price()
                self._last_price = price
                
                self._log("price_check", 
                         cycle=cycle,
                         price=round(price, 2),
                         entry=self.entry_price,
                         executed_targets=f"{len(self._executed_parts)}/{len(self.targets)}",
                         remaining_fraction=round(self._remaining_fraction, 4))

                # ============ STOP LOSS ============
                if self.stop_loss_pct is not None:
                    if self.mode == "sell":
                        threshold = self.entry_price * (1 + self.stop_loss_pct / 100)
                        if price <= threshold:
                            self._log("stop_loss_triggered", 
                                     price=price, 
                                     threshold=threshold,
                                     message="Acionando STOP LOSS")
                            
                            # Calcula fração total restante
                            total_remaining = self._remaining_fraction
                            for pct, portion in self.targets:
                                if pct not in self._executed_parts:
                                    total_remaining += portion
                            
                            if total_remaining > 0.01:
                                self._execute_fraction(total_remaining, "sell")
                                self._record_trade("stop_loss", price, total_remaining)
                            
                            self._stopped.set()
                            break

                # ============ TRAILING STOP ============
                if self.trailing_stop_pct is not None:
                    if self.mode == "sell":
                        self._peak_price = max(self._peak_price, price)
                        drop_threshold = self._peak_price * (1 - self.trailing_stop_pct / 100)
                        
                        if price <= drop_threshold:
                            self._log("trailing_stop_triggered", 
                                     price=price, 
                                     peak=self._peak_price,
                                     threshold=drop_threshold,
                                     message="Acionando TRAILING STOP")
                            
                            # Calcula fração total restante
                            total_remaining = self._remaining_fraction
                            for pct, portion in self.targets:
                                if pct not in self._executed_parts:
                                    total_remaining += portion
                            
                            if total_remaining > 0.01:
                                self._execute_fraction(total_remaining, "sell")
                                self._record_trade("trailing_stop", price, total_remaining)
                            
                            self._stopped.set()
                            break

                # ============ TARGETS ============
                targets_hit_this_cycle = 0
                
                for pct, portion in self.targets:
                    # Pula targets já executados
                    if pct in self._executed_parts: 
                        continue
                    
                    target = self.entry_price * (1 + pct / 100)
                    
                    if self.mode == "sell" and price >= target:
                        self._log("target_hit", 
                                 target_pct=pct,
                                 target_price=target,
                                 current_price=price,
                                 portion=portion,
                                 message=f"TARGET {pct}% ATINGIDO!")
                        
                        self._execute_fraction(portion, "sell")
                        self._record_trade(f"target_sell_{pct}%", price, portion)
                        self._executed_parts.append(pct)
                        targets_hit_this_cycle += 1
                        
                        self._log("target_executed",
                                 executed_targets=len(self._executed_parts),
                                 total_targets=len(self.targets),
                                 remaining_targets=len(self.targets) - len(self._executed_parts),
                                 remaining_fraction=round(self._remaining_fraction, 4))
                    
                    elif self.mode == "buy" and price <= target:
                        self._log("target_hit", 
                                 target_pct=pct,
                                 target_price=target,
                                 current_price=price,
                                 portion=portion,
                                 message=f"TARGET {pct}% ATINGIDO!")
                        
                        self._execute_fraction(portion, "buy")
                        self._record_trade(f"target_buy_{pct}%", price, portion)
                        self._executed_parts.append(pct)
                        targets_hit_this_cycle += 1
                        
                        self._log("target_executed",
                                 executed_targets=len(self._executed_parts),
                                 total_targets=len(self.targets),
                                 remaining_targets=len(self.targets) - len(self._executed_parts),
                                 remaining_fraction=round(self._remaining_fraction, 4))

                # Log de progresso se algum target foi atingido
                if targets_hit_this_cycle > 0:
                    self._log("cycle_summary",
                             targets_hit=targets_hit_this_cycle,
                             total_executed=len(self._executed_parts),
                             total_targets=len(self.targets),
                             status="CONTINUANDO..." if self._should_continue() else "FINALIZANDO")

                # Verifica se deve continuar APÓS processar todos os targets
                if not self._should_continue():
                    self._log("completion_check",
                             executed_targets=len(self._executed_parts),
                             total_targets=len(self.targets),
                             remaining_fraction=self._remaining_fraction,
                             message="Todos os targets foram executados!")
                    break

                time.sleep(self.check_interval)
                
        except KeyboardInterrupt:
            self._log("bot_interrupted", message="Interrompido pelo usuário")
        except Exception as e:
            self._log("bot_error", 
                     error=str(e), 
                     error_type=type(e).__name__,
                     message="Erro não tratado no bot")
            import traceback
            self._log("bot_traceback", traceback=traceback.format_exc())
        finally:
            self._finalize()

    def _finalize(self):
        """Finaliza e salva histórico"""
        total_profit = sum(t.get("profit_usdt", 0) for t in self.executed_trades)
        total_executed_portion = sum(t.get("portion", 0) for t in self.executed_trades)
        
        self._log("bot_finalized",
                 executed_trades=len(self.executed_trades),
                 executed_targets=f"{len(self._executed_parts)}/{len(self.targets)}",
                 total_executed_portion=round(total_executed_portion, 4),
                 total_profit_usdt=round(total_profit, 2),
                 remaining_fraction=round(self._remaining_fraction, 4),
                 duration_seconds=round(time.time() - self._start_ts, 1),
                 message="Bot finalizado com sucesso")
        
        final = {
            "id": self._id,
            "symbol": self.symbol,
            "entry_price": self.entry_price,
            "mode": self.mode,
            "targets": self.targets,
            "start_ts": self._start_ts,
            "end_ts": time.time(),
            "executed_trades": self.executed_trades,
            "executed_targets": len(self._executed_parts),
            "total_targets": len(self.targets),
            "total_profit": total_profit,
            "total_executed_portion": round(total_executed_portion, 6),
            "remaining_fraction": round(self._remaining_fraction, 6),
            "dry_run": self.dry_run,
            "final_status": "completed" if len(self._executed_parts) >= len(self.targets) else "stopped"
        }
        _append_history(final)

    def stop(self):
        self._stopped.set()
        self._log("stop_requested", message="Solicitado parada do bot")

# ====================== CLI ======================
def parse_targets(s: str) -> List[Tuple[float, float]]:
    out = []
    for p in s.split(","):
        if ":" in p:
            try:
                a, b = p.split(":")
                out.append((float(a), float(b)))
            except:
                pass
    return out

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--symbol", default="BTC-USDT")
    p.add_argument("--entry", type=float, default=88000.0)
    p.add_argument("--mode", default="sell")
    p.add_argument("--targets", default="1:0.3,3:0.5,5:0.2")
    p.add_argument("--trailing", type=float, default=None)
    p.add_argument("--stoploss", type=float, default=None)
    p.add_argument("--size", type=float, default=0.001)
    p.add_argument("--funds", type=float, default=100.0)
    p.add_argument("--interval", type=float, default=5.0)
    p.add_argument("--dry", action="store_true", default=False)
    p.add_argument("--no-dry", dest="dry", action="store_false")
    p.add_argument("--verbose", action="store_true", default=False)
    args = p.parse_args()

    print(f"[START] Iniciando bot com:", file=sys.stderr, flush=True)
    print(f"  Symbol: {args.symbol}", file=sys.stderr, flush=True)
    print(f"  Entry: {args.entry}", file=sys.stderr, flush=True)
    print(f"  Targets: {args.targets}", file=sys.stderr, flush=True)
    print(f"  Dry Run: {args.dry}", file=sys.stderr, flush=True)

    bot = EnhancedTradeBot(
        symbol=args.symbol,
        entry_price=args.entry,
        mode=args.mode,
        targets=parse_targets(args.targets),
        trailing_stop_pct=args.trailing,
        stop_loss_pct=args.stoploss,
        size=args.size,
        funds=args.funds,
        check_interval=args.interval,
        dry_run=args.dry,
        verbose=args.verbose
    )
    
    bot.start()
