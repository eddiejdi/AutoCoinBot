# kucoin_app/api.py
# API utilities for KuCoin – robust, with retry logic and professional logging

import os
import time
import hmac
import hashlib
import base64
import json
import requests
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Callable
from functools import wraps

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(name)s | %(message)s',
    handlers=[
        logging.FileHandler('kucoin_app.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Load .env
try:
    from dotenv import load_dotenv
    THIS_DIR = Path(__file__).resolve().parent
    ENV_FILE = THIS_DIR / ".env"
    if not ENV_FILE.exists():
        ENV_FILE = THIS_DIR.parent / ".env"
    if ENV_FILE.exists():
        load_dotenv(dotenv_path=str(ENV_FILE))
except Exception as e:
    logger.warning(f"Could not load .env: {e}")

# Config from env
API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")
API_PASSPHRASE = os.getenv("API_PASSPHRASE")
API_KEY_VERSION = os.getenv("API_KEY_VERSION", "2")
KUCOIN_BASE = os.getenv("KUCOIN_BASE", "https://api.kucoin.com").rstrip("/")

# Rate limiting
_last_request_time = 0
_min_request_interval = 0.1  # 100ms between requests

def rate_limit():
    """Simple rate limiting to avoid API throttling"""
    global _last_request_time
    now = time.time()
    elapsed = now - _last_request_time
    if elapsed < _min_request_interval:
        time.sleep(_min_request_interval - elapsed)
    _last_request_time = time.time()

def retry_on_failure(max_retries: int = 3, backoff: float = 2.0):
    """Decorator for retrying failed API calls with exponential backoff"""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except requests.exceptions.RequestException as e:
                    if attempt == max_retries - 1:
                        logger.error(f"Failed after {max_retries} attempts: {e}")
                        raise
                    wait_time = backoff ** attempt
                    logger.warning(f"Attempt {attempt + 1} failed, retrying in {wait_time}s: {e}")
                    time.sleep(wait_time)
                except Exception as e:
                    logger.error(f"Unexpected error in {func.__name__}: {e}")
                    raise
            return None
        return wrapper
    return decorator

def validate_credentials():
    """Validate that API credentials are set"""
    if not API_KEY or not API_SECRET or not API_PASSPHRASE:
        raise RuntimeError(
            "API credentials not configured. Please set API_KEY, API_SECRET, "
            "and API_PASSPHRASE in .env file or environment variables"
        )

def _server_time() -> int:
    """Return server timestamp in milliseconds"""
    try:
        rate_limit()
        r = requests.get(f"{KUCOIN_BASE}/api/v1/timestamp", timeout=5)
        if r.status_code == 200:
            return int(r.json().get("data", int(time.time() * 1000)))
    except Exception as e:
        logger.warning(f"Failed to get server time, using local: {e}")
    return int(time.time() * 1000)

def _build_headers(method: str, endpoint: str, body_str: str = "") -> Dict[str, str]:
    """Build KuCoin API headers for private endpoints"""
    validate_credentials()
    
    ts = str(_server_time())
    method_up = method.upper()
    to_sign = ts + method_up + endpoint + (body_str or "")
    signature = base64.b64encode(
        hmac.new(API_SECRET.encode(), to_sign.encode(), hashlib.sha256).digest()
    ).decode()
    passphrase = base64.b64encode(
        hmac.new(API_SECRET.encode(), API_PASSPHRASE.encode(), hashlib.sha256).digest()
    ).decode()

    return {
        "KC-API-KEY": API_KEY,
        "KC-API-SIGN": signature,
        "KC-API-TIMESTAMP": ts,
        "KC-API-PASSPHRASE": passphrase,
        "KC-API-KEY-VERSION": API_KEY_VERSION,
        "Content-Type": "application/json"
    }

@retry_on_failure(max_retries=3)
def get_accounts_raw() -> List[Dict[str, Any]]:
    """Return raw accounts list from KuCoin"""
    endpoint = "/api/v1/accounts"
    headers = _build_headers("GET", endpoint, "")
    rate_limit()
    r = requests.get(KUCOIN_BASE + endpoint, headers=headers, timeout=15)
    if r.status_code != 200:
        raise RuntimeError(f"API accounts error: {r.status_code} - {r.text}")
    logger.info("Successfully fetched accounts")
    return r.json().get("data", [])

def get_balance(details: bool = False) -> Any:
    """
    Get total balance converted to USDT
    
    Args:
        details: If True, returns (total_usdt, rows) with detailed breakdown
        
    Returns:
        float or tuple: Total USDT value or (total_usdt, detailed_rows)
    """
    try:
        accounts = get_accounts_raw()
        total_usdt = 0.0
        rows = []
        
        for acc in accounts:
            curr = acc.get("currency")
            balance = float(acc.get("balance", 0) or 0)
            available = float(acc.get("available", 0) or 0)
            holds = float(acc.get("holds", 0) or 0)

            converted = None
            used_pair = None

            if balance > 0:
                # Try direct USDT/USDC
                if curr in ("USDT", "USDC"):
                    converted = balance
                    used_pair = curr
                else:
                    # Try conversion pairs
                    for quote in ("USDT", "USDC"):
                        symbol = f"{curr}-{quote}"
                        try:
                            ob = get_orderbook_price(symbol)
                            price = ob.get("mid_price")
                            if price:
                                converted = balance * price
                                used_pair = symbol
                                total_usdt += converted
                                break
                        except Exception:
                            continue

            rows.append({
                "currency": curr,
                "balance": balance,
                "available": available,
                "holds": holds,
                "converted_usdt": round(converted, 6) if converted else 0.0,
                "used_pair": used_pair
            })

        total_usdt = round(total_usdt, 6)
        logger.info(f"Total balance: ${total_usdt:,.2f} USDT")
        
        if details:
            return total_usdt, rows
        return total_usdt

    except Exception as e:
        logger.error(f"Error getting balance: {e}")
        raise


def _extract_price_from_resp(resp: Any) -> Optional[float]:
    """
    Extrai um preço numérico de resp que pode ser float/str/dict.
    Prioriza mid_price, depois média best_ask/best_bid, depois outras chaves comuns.
    """
    try:
        if resp is None:
            return None
        if isinstance(resp, (int, float)):
            return api._extract_price_from_resp(resp)
        if isinstance(resp, str):
            try:
                return api._extract_price_from_resp(resp)
            except Exception:
                return None
        if isinstance(resp, dict):
            # prefer mid_price
            if "mid_price" in resp and resp["mid_price"] is not None:
                try:
                    return float(resp["mid_price"])
                except Exception:
                    pass
            # average best_ask/best_bid
            if ("best_ask" in resp and resp["best_ask"] is not None) and ("best_bid" in resp and resp["best_bid"] is not None):
                try:
                    return (float(resp["best_ask"]) + float(resp["best_bid"])) / 2.0
                except Exception:
                    pass
            # other common keys
            for k in ("price","last","close","value","lastPrice","price_24h","ask","bid","bestAsk","bestBid"):
                if k in resp and resp[k] is not None:
                    try:
                        return float(resp[k])
                    except Exception:
                        # nested dict
                        if isinstance(resp[k], dict):
                            for kk in ("price","last","close","value"):
                                if kk in resp[k] and resp[k][kk] is not None:
                                    try:
                                        return float(resp[k][kk])
                                    except Exception:
                                        continue
                        continue
            # nested containers
            if "data" in resp:
                return _extract_price_from_resp(resp["data"])
            if "tick" in resp:
                return _extract_price_from_resp(resp["tick"])
            if "ticks" in resp and isinstance(resp["ticks"], (list,tuple)) and len(resp["ticks"])>0:
                return _extract_price_from_resp(resp["ticks"][0])
        if isinstance(resp, (list,tuple)) and len(resp)>0:
            return _extract_price_from_resp(resp[0])
    except Exception:
        return None
    return None


@retry_on_failure(max_retries=2)
def get_orderbook_price(symbol: str) -> Optional[float]:
    """
    Wrapper: returns a numeric price when possible.
    Internally calls the original low-level orderbook API (if you have one).
    If the low-level call returns a dict (e.g. with mid_price/best_ask/best_bid),
    this function extracts a float and returns it. On failure, returns the raw resp
    or None depending on original behavior — but preferred is to return None.
    """
    # --- try to call existing low-level function if it exists ---
    # several projects implemented an internal function named _get_orderbook or similar;
    # adjust accordingly if your file has another function name.
    try:
        # try the low-level implementation if present (preserve compatibility)
        if "get_orderbook_price_raw" in globals():
            resp = globals()["get_orderbook_price_raw"](symbol)
        else:
            # fallback: if there is an older get_orderbook_price_raw implementation under a different name,
            # try calling a function that previously provided dicts (adjust if needed).
            # If there is no raw call, try previous implementation signature (may raise).
            # We'll attempt to call the existing implementation under a different name:
            if "_get_orderbook_price" in globals():
                resp = globals()["_get_orderbook_price"](symbol)
            else:
                # If there is no raw helper, assume there is some lower-level code here.
                # Fallback: attempt to call a pre-existing get_orderbook_price (this function may recurse if not careful).
                # To avoid recursion, check if this function has been replaced previously:
                raw = globals().get("__original_get_orderbook_price_impl__")
                if raw:
                    resp = raw(symbol)
                else:
                    # no alternative; try calling a function that may exist in this module (legacy)
                    # If this will recurse, it will be caught by except below.
                    resp = None
    except Exception:
        # If calling raw failed, fallback to None
        resp = None

    # If resp is already numeric or convertible, extract it
    price = _extract_price_from_resp(resp)
    if price is not None:
        return price

    # If extraction failed, but resp is numeric-ish, attempt float
    try:
        if resp is not None:
            return api._extract_price_from_resp(resp)
    except Exception:
        pass

    # as last resort return resp (old behavior) or None
    return None

def get_price(symbol: str) -> Optional[float]:
    """Shortcut for mid price"""
    ob = get_orderbook_price(symbol)
    return ob.get("mid_price")

@retry_on_failure(max_retries=3)
def get_candles(symbol: str, ktype: str = "1hour", startAt: int = None, 
                endAt: int = None, timeout: float = 12.0) -> List[Any]:
    """Fetch candles from KuCoin public endpoint"""
    url = f"{KUCOIN_BASE}/api/v1/market/candles?type={ktype}&symbol={symbol}"
    if startAt:
        url += f"&startAt={int(startAt)}"
    if endAt:
        url += f"&endAt={int(endAt)}"
    
    rate_limit()
    r = requests.get(url, timeout=timeout)
    if r.status_code != 200:
        raise RuntimeError(f"Error fetching candles: {r.status_code} - {r.text}")
    
    candles = r.json().get("data", [])
    logger.info(f"Fetched {len(candles)} candles for {symbol}")
    return candles

def get_candles_safe(symbol: str, ktype: str = "1hour", startAt: int = None, 
                     endAt: int = None) -> List[List[Any]]:
    """Robust wrapper returning normalized candles"""
    try:
        raw = get_candles(symbol, ktype=ktype, startAt=startAt, endAt=endAt)
        normalized = []
        
        for item in raw:
            try:
                if isinstance(item, dict):
                    t = int(item.get("time") or item.get("timestamp") or 0)
                    o = float(item.get("open", 0) or 0)
                    c = float(item.get("close", 0) or 0)
                    h = float(item.get("high", 0) or 0)
                    l = float(item.get("low", 0) or 0)
                    v = float(item.get("volume", 0) or 0)
                    amt = float(item.get("amount", 0) or 0)
                    normalized.append([t, o, c, h, l, v, amt])
                elif isinstance(item, (list, tuple)) and len(item) >= 6:
                    t = int(item[0])
                    o = float(item[1])
                    c = float(item[2])
                    h = float(item[3])
                    l = float(item[4])
                    v = float(item[5])
                    amt = float(item[6]) if len(item) > 6 else 0.0
                    normalized.append([t, o, c, h, l, v, amt])
            except Exception:
                continue
                
        return normalized
    except Exception as e:
        logger.error(f"Error in get_candles_safe: {e}")
        return []

@retry_on_failure(max_retries=3)
def place_market_order(symbol: str, side: str, funds: float = None, 
                       size: float = None) -> Dict[str, Any]:
    """Place a market order (private endpoint)"""
    validate_credentials()
    
    endpoint = "/api/v1/orders"
    payload = {
        "clientOid": str(int(time.time() * 1e6)),
        "side": side.lower(),
        "symbol": symbol,
        "type": "market",
    }
    
    if funds is not None:
        payload["funds"] = str(round(float(funds), 8))
    if size is not None:
        payload["size"] = str(round(float(size), 12))
    
    body_str = json.dumps(payload, separators=(",", ":"))
    headers = _build_headers("POST", endpoint, body_str)
    
    rate_limit()
    r = requests.post(KUCOIN_BASE + endpoint, headers=headers, 
                     data=body_str, timeout=15)
    
    if r.status_code not in (200, 201):
        raise RuntimeError(f"Error placing order: {r.status_code} - {r.text}")
    
    result = r.json()
    logger.info(f"Order placed: {side} {symbol} - {payload}")
    return result

if __name__ == "__main__":
    logger.info("Running API self-test...")
    try:
        logger.info(f"API_KEY present: {bool(API_KEY)}")
        logger.info(f"KUCOIN_BASE: {KUCOIN_BASE}")
        
        # Test price fetch
        p = get_price("BTC-USDT")
        logger.info(f"BTC-USDT price: ${p:,.2f}")
        
        # Test candles
        c = get_candles_safe("BTC-USDT", ktype="1hour")
        logger.info(f"Fetched {len(c)} candles")
        
    except Exception as e:
        logger.error(f"Self-test failed: {e}")



# --- wrapper injection (auto) ---
# Preserve original implementation if present
try:
    __original_get_orderbook_price_impl__
except NameError:
    if "get_orderbook_price" in globals():
        __original_get_orderbook_price_impl__ = globals()["get_orderbook_price"]
    else:
        __original_get_orderbook_price_impl__ = None

def _extract_price_from_resp(resp):
    try:
        if resp is None:
            return None
        if isinstance(resp, (int, float)):
            return api._extract_price_from_resp(resp)
        if isinstance(resp, str):
            try: return api._extract_price_from_resp(resp)
            except: return None
        if isinstance(resp, dict):
            if "mid_price" in resp and resp["mid_price"] is not None:
                try: return float(resp["mid_price"])
                except: pass
            if ("best_ask" in resp and resp["best_ask"] is not None) and ("best_bid" in resp and resp["best_bid"] is not None):
                try: return (float(resp["best_ask"]) + float(resp["best_bid"]))/2.0
                except: pass
            for k in ("price","last","close","value","lastPrice","price_24h","ask","bid","bestAsk","bestBid"):
                if k in resp and resp[k] is not None:
                    try: return float(resp[k])
                    except:
                        if isinstance(resp[k], dict):
                            for kk in ("price","last","close","value"):
                                if kk in resp[k] and resp[k][kk] is not None:
                                    try: return float(resp[k][kk])
                                    except: continue
                        continue
            if "tick" in resp:
                return _extract_price_from_resp(resp["tick"])
            if "data" in resp:
                return _extract_price_from_resp(resp["data"])
            if "ticks" in resp and isinstance(resp["ticks"], (list,tuple)) and len(resp["ticks"])>0:
                return _extract_price_from_resp(resp["ticks"][0])
        if isinstance(resp, (list,tuple)) and len(resp)>0:
            return _extract_price_from_resp(resp[0])
    except Exception:
        return None
    return None

def get_orderbook_price(symbol):
    """
    Robust wrapper: calls original implementation if present, then extracts a numeric price.
    Returns float when possible, otherwise None.
    """
    resp = None
    try:
        if __original_get_orderbook_price_impl__:
            resp = __original_get_orderbook_price_impl__(symbol)
        else:
            # No original impl found in module: try any available low-level helpers (best-effort)
            if "_get_orderbook_price" in globals():
                resp = globals()["_get_orderbook_price"](symbol)
            elif "get_orderbook_price_raw" in globals():
                resp = globals()["get_orderbook_price_raw"](symbol)
            else:
                resp = None
    except Exception:
        resp = None

    price = _extract_price_from_resp(resp)
    if price is not None:
        return price
    try:
        if resp is not None:
            return api._extract_price_from_resp(resp)
    except Exception:
        pass
    return None
# --- end wrapper injection ---

def get_orderbook_price(symbol: str):
    """
    Direct, robust implementation: queries KuCoin level1 orderbook and returns a dict
    with mid_price, best_ask, best_bid and timestamp when available.
    """
    base = globals().get('KUCOIN_BASE', 'https://api.kucoin.com').rstrip('/')
    url = f"{base}/api/v1/market/orderbook/level1?symbol={symbol}"
    try:
        try:
            rate_limit()
        except Exception:
            pass
        r = requests.get(url, timeout=5)
        r.raise_for_status()
        j = r.json()
    except Exception:
        return None

    data = j.get("data") if isinstance(j, dict) and "data" in j else j
    if not data:
        return None
    out = {}
    for k in ("mid_price","price","last","lastPrice","close"):
        if k in data and data[k] is not None:
            try: out["mid_price"] = float(data[k]); break
            except: pass
    for ka in ("bestAsk","best_ask","ask"):
        if ka in data and data[ka] is not None:
            try: out["best_ask"] = float(data[ka]); break
            except: pass
    for kb in ("bestBid","best_bid","bid"):
        if kb in data and data[kb] is not None:
            try: out["best_bid"] = float(data[kb]); break
            except: pass
    if "mid_price" not in out and "best_ask" in out and "best_bid" in out:
        out["mid_price"] = (out["best_ask"] + out["best_bid"]) / 2.0
    # try timestamp fields
    for kt in ("timestamp","time","ts"):
        if kt in data and data[kt] is not None:
            try: out["timestamp"] = int(data[kt]); break
            except: pass
    return out


def _has_keys():
    return bool(API_KEY and API_SECRET and API_PASSPHRASE)
