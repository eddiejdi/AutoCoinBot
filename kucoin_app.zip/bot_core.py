# bot_core.py — VERSÃO COM AUTO-RESTART (Recomeça após completar estratégia)
from __future__ import annotations
import time
import json
import uuid
import threading
import os
import sys
import logging
import logging.handlers
from pathlib import Path
from typing import List, Tuple, Optional

# Tenta importar a API
try:
    from . import api
    # Verifica se tem credenciais válidas
    HAS_REAL_API = bool(api.API_KEY and api.API_SECRET and api.API_PASSPHRASE)
    if HAS_REAL_API:
        print(f"[INFO] API KuCoin carregada com sucesso", file=sys.stderr, flush=True)
    else:
        print(f"[WARN] API carregada mas sem credenciais", file=sys.stderr, flush=True)
        HAS_REAL_API = False
except Exception as e:
    print(f"[INFO] API não encontrada: {e}", file=sys.stderr, flush=True)
    print("[INFO] Rodando em SIMULAÇÃO TOTAL", file=sys.stderr, flush=True)
    HAS_REAL_API = False
    api = None

ROOT = Path(__file__).resolve().parent
HISTORY_JSON = ROOT / "bot_history.json"
LOG_DIR = ROOT / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

# ====================== LOGGER CORRIGIDO ======================
def setup_bot_logger(bot_id: str) -> logging.Logger:
    """Logger que imprime JSON puro no STDOUT para ui.py capturar"""
    logger = logging.getLogger(f"bot_{bot_id}")
    if logger.handlers:
        return logger
    
    logger.setLevel(logging.INFO)
    logger.propagate = False
    
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setLevel(logging.INFO)
    
    class JSONFormatter(logging.Formatter):
        def format(self, record):
            return record.getMessage()
    
    stdout_handler.setFormatter(JSONFormatter())
    logger.addHandler(stdout_handler)
    
    try:
        file_handler = logging.handlers.RotatingFileHandler(
            LOG_DIR / f"bot_{bot_id}.log",
            maxBytes=5*1024*1024,
            backupCount=3,
            encoding="utf-8"
        )
        file_handler.setFormatter(JSONFormatter())
        logger.addHandler(file_handler)
    except Exception as e:
        print(f"[WARN] Não foi possível criar arquivo de log: {e}", file=sys.stderr, flush=True)
    
    return logger

# ====================== HISTÓRICO ======================
def _append_history(entry: dict):
    hist = []
    if HISTORY_JSON.exists():
        try:
            hist = json.loads(HISTORY_JSON.read_text(encoding="utf-8"))
        except:
            pass
    hist.append(entry)
    try:
        HISTORY_JSON.write_text(json.dumps(hist, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        print(f"[ERROR] Salvando histórico: {e}", file=sys.stderr, flush=True)

# ====================== ORDEM REAL/SIMULADA ======================
def place_market_order(symbol: str, side: str, funds: Optional[float] = None,
                       size: Optional[float] = None, dry_run: bool = True,
                       logger: Optional[logging.Logger] = None) -> dict:
    """
    Coloca ordem de mercado real ou simulada
    
    Args:
        symbol: Par de trading (ex: BTC-USDT)
        side: "buy" ou "sell"
        funds: Quantidade em quote currency (USDT)
        size: Quantidade em base currency (BTC)
        dry_run: Se True, apenas simula
        logger: Logger para registrar operação
    
    Returns:
        dict: Resposta da API ou simulação
    """
    payload = {
        "clientOid": str(uuid.uuid4()),
        "side": side,
        "symbol": symbol,
        "type": "market",
    }
    if funds: 
        payload["funds"] = str(round(funds, 8))
    if size: 
        payload["size"] = str(round(size, 12))

    # SIMULAÇÃO
    if dry_run or not HAS_REAL_API:
        sim = {
            "simulated": True,
            "clientOid": payload["clientOid"],
            "side": side,
            "symbol": symbol,
            "funds": payload.get("funds"),
            "size": payload.get("size"),
            "timestamp": int(time.time() * 1000),
            "reason": "dry_run=True" if dry_run else "no_api_credentials"
        }
        if logger:
            logger.info(json.dumps({
                "event": "simulated_order", 
                "payload": payload,
                "result": "success"
            }))
        return sim

    # ORDEM REAL NA API KUCOIN
    if logger:
        logger.info(json.dumps({
            "event": "placing_real_order",
            "symbol": symbol,
            "side": side,
            "funds": payload.get("funds"),
            "size": payload.get("size")
        }))
    
    try:
        # Usa a função da API importada
        result = api.place_market_order(
            symbol=symbol,
            side=side,
            funds=float(funds) if funds else None,
            size=float(size) if size else None
        )
        
        if logger:
            logger.info(json.dumps({
                "event": "real_order_success",
                "order_id": result.get("data", {}).get("orderId") if isinstance(result, dict) else None,
                "result": result
            }))
        
        return result
        
    except Exception as e:
        error_msg = str(e)
        if logger:
            logger.error(json.dumps({
                "event": "real_order_error",
                "error": error_msg,
                "symbol": symbol,
                "side": side
            }))
        
        # Retorna erro estruturado
        return {
            "error": True,
            "message": error_msg,
            "symbol": symbol,
            "side": side,
            "timestamp": int(time.time() * 1000)
        }

# ====================== BOT PRINCIPAL ======================
class EnhancedTradeBot:
    def __init__(self, symbol: str, entry_price: float, mode: str = "sell",
                 targets: Optional[List[Tuple[float, float]]] = None,
                 trailing_stop_pct: Optional[float] = None,
                 stop_loss_pct: Optional[float] = None,
                 size: Optional[float] = None, funds: Optional[float] = None,
                 check_interval: float = 5.0, dry_run: bool = True,
                 verbose: bool = False, auto_restart: bool = False,
                 max_cycles: int = 0):

        self.symbol = symbol.upper()
        self.entry_price = float(entry_price)
        self.mode = mode.lower()
        self.targets = sorted(targets or [], key=lambda x: x[0])
        self.trailing_stop_pct = trailing_stop_pct
        self.stop_loss_pct = stop_loss_pct
        self.size = size
        self.funds = funds
        self.check_interval = check_interval
        self.dry_run = dry_run or not HAS_REAL_API
        self.auto_restart = auto_restart
        self.max_cycles = max_cycles

        self._id = str(uuid.uuid4())[:8]
        self._logger = setup_bot_logger(self._id)
        self._stopped = threading.Event()
        self._start_ts = time.time()
        self._last_price = entry_price
        self._peak_price = entry_price
        self._valley_price = entry_price
        self._executed_parts: List[float] = []
        self._remaining_fraction = 1.0
        self._current_cycle = 0
        self._total_cycles_completed = 0
        
        # Calcula fração restante considerando targets
        for _, portion in self.targets:
            self._remaining_fraction -= portion
        
        self.executed_trades: List[dict] = []
        self.all_cycles_history: List[dict] = []

        self._log("bot_initialized", 
                  symbol=self.symbol, 
                  entry_price=self.entry_price,
                  mode=self.mode, 
                  targets=self.targets,
                  initial_remaining_fraction=round(self._remaining_fraction, 4),
                  auto_restart=self.auto_restart,
                  max_cycles=self.max_cycles if self.max_cycles > 0 else "unlimited",
                  dry_run=self.dry_run,
                  has_api=HAS_REAL_API)

    def _log(self, event: str, **kwargs):
        """Log estruturado em JSON puro para STDOUT"""
        log_entry = {
            "bot_id": self._id,
            "event": event,
            "cycle": self._current_cycle,
            "timestamp": time.time(),
            **kwargs
        }
        message = json.dumps(log_entry, ensure_ascii=False, default=str)
        self._logger.info(message)
        sys.stdout.flush()

    def _get_current_price(self) -> float:
        """Obtém preço atual (real ou simulado)"""
        # SIMULAÇÃO: preço crescente para testes
        if not HAS_REAL_API or self.dry_run:
            elapsed = time.time() - self._start_ts
            # 10% de crescimento em 30 segundos
            simulated = self.entry_price * (1 + (elapsed / 30) * 0.1)
            self._log("price_simulated", 
                     price=round(simulated, 2), 
                     elapsed=round(elapsed, 1),
                     growth_pct=round(((simulated / self.entry_price) - 1) * 100, 2))
            return simulated
        
        # PREÇO REAL DA API
        try:
            orderbook = api.get_orderbook_price(self.symbol)
            
            if orderbook is None:
                self._log("price_fetch_failed", 
                         message="Orderbook retornou None, usando último preço",
                         last_price=self._last_price)
                return self._last_price
            
            # Extrai preço do orderbook
            if isinstance(orderbook, dict):
                price = orderbook.get("mid_price")
                if price is None and "best_ask" in orderbook and "best_bid" in orderbook:
                    price = (float(orderbook["best_ask"]) + float(orderbook["best_bid"])) / 2.0
                
                if price:
                    self._log("price_fetched",
                             price=round(float(price), 2),
                             spread=round(abs(float(orderbook.get("best_ask", 0)) - 
                                            float(orderbook.get("best_bid", 0))), 2) if "best_ask" in orderbook else None)
                    return float(price)
            
            elif isinstance(orderbook, (int, float)):
                self._log("price_fetched", price=round(float(orderbook), 2))
                return float(orderbook)
            
            # Fallback
            self._log("price_format_unexpected",
                     orderbook_type=type(orderbook).__name__,
                     using_last_price=self._last_price)
            return self._last_price
            
        except Exception as e:
            self._log("price_fetch_error", 
                     error=str(e),
                     using_last_price=self._last_price)
            return self._last_price

    def _calculate_portion_size(self, portion: float) -> float:
        if self.size: 
            return self.size * portion
        price = self._get_current_price()
        if self.funds and price: 
            return (self.funds * portion) / price
        return 0.0

    def _execute_fraction(self, portion: float, side: str):
        size = self._calculate_portion_size(portion)
        self._log("executing_order", side=side, portion=portion, size=size)
        result = place_market_order(
            self.symbol, side, size=size, 
            dry_run=self.dry_run, logger=self._logger
        )
        return result

    def _record_trade(self, kind: str, price: float, portion: float):
        """Registra trade executado (real ou simulado)"""
        profit = 0
        if "sell" in kind and self.size:
            profit = portion * (price - self.entry_price) * self.size
        elif "buy" in kind and self.size:
            profit = portion * (self.entry_price - price) * self.size

        trade = {
            "timestamp": time.time(),
            "cycle": self._current_cycle,
            "kind": kind,
            "price": round(price, 2),
            "portion": round(portion, 4),
            "profit_usdt": round(profit, 2),
            "simulated": self.dry_run or not HAS_REAL_API,
            "mode": "SIMULATION" if (self.dry_run or not HAS_REAL_API) else "REAL_API"
        }
        self.executed_trades.append(trade)
        
        # Log com destaque para ordens reais
        if not self.dry_run and HAS_REAL_API:
            self._log("REAL_TRADE_EXECUTED", **trade, alert="REAL_MONEY")
        else:
            self._log("trade_executed", **trade)

    def _should_continue_cycle(self) -> bool:
        """Verifica se o ciclo atual deve continuar"""
        if self._stopped.is_set():
            return False
        
        if len(self._executed_parts) < len(self.targets):
            return True
        
        if self._remaining_fraction > 0.01:
            return True
        
        return False

    def _reset_cycle(self):
        """Reseta estado para novo ciclo"""
        self._log("cycle_reset", 
                 message="Resetando bot para novo ciclo",
                 completed_cycles=self._total_cycles_completed)
        
        # Salva histórico do ciclo anterior
        cycle_summary = {
            "cycle_number": self._current_cycle,
            "trades": self.executed_trades.copy(),
            "total_profit": sum(t.get("profit_usdt", 0) for t in self.executed_trades),
            "start_ts": self._start_ts,
            "end_ts": time.time(),
            "duration": round(time.time() - self._start_ts, 1)
        }
        self.all_cycles_history.append(cycle_summary)
        
        # Reseta variáveis do ciclo
        self._executed_parts = []
        self._remaining_fraction = 1.0
        for _, portion in self.targets:
            self._remaining_fraction -= portion
        
        self.executed_trades = []
        self._start_ts = time.time()
        self._peak_price = self._last_price
        self._valley_price = self._last_price
        
        # Atualiza entry_price para o preço atual
        self.entry_price = self._last_price
        
        self._log("cycle_reset_complete",
                 new_entry_price=self.entry_price,
                 message="Bot pronto para novo ciclo")

    def _run_single_cycle(self):
        """Executa um único ciclo de estratégia"""
        self._current_cycle += 1
        self._log("cycle_started", 
                 cycle_number=self._current_cycle,
                 entry_price=self.entry_price,
                 message=f"Iniciando ciclo {self._current_cycle}")
        
        try:
            iteration = 0
            while self._should_continue_cycle():
                iteration += 1
                price = self._get_current_price()
                self._last_price = price
                
                self._log("price_check", 
                         iteration=iteration,
                         price=round(price, 2),
                         entry=self.entry_price,
                         executed_targets=f"{len(self._executed_parts)}/{len(self.targets)}",
                         remaining_fraction=round(self._remaining_fraction, 4))

                # ============ STOP LOSS ============
                if self.stop_loss_pct is not None:
                    if self.mode == "sell":
                        threshold = self.entry_price * (1 + self.stop_loss_pct / 100)
                        if price <= threshold:
                            self._log("stop_loss_triggered", 
                                     price=price, 
                                     threshold=threshold,
                                     message="Acionando STOP LOSS")
                            
                            total_remaining = self._remaining_fraction
                            for pct, portion in self.targets:
                                if pct not in self._executed_parts:
                                    total_remaining += portion
                            
                            if total_remaining > 0.01:
                                self._execute_fraction(total_remaining, "sell")
                                self._record_trade("stop_loss", price, total_remaining)
                            
                            return "stop_loss"

                # ============ TRAILING STOP ============
                if self.trailing_stop_pct is not None:
                    if self.mode == "sell":
                        self._peak_price = max(self._peak_price, price)
                        drop_threshold = self._peak_price * (1 - self.trailing_stop_pct / 100)
                        
                        if price <= drop_threshold:
                            self._log("trailing_stop_triggered", 
                                     price=price, 
                                     peak=self._peak_price,
                                     threshold=drop_threshold,
                                     message="Acionando TRAILING STOP")
                            
                            total_remaining = self._remaining_fraction
                            for pct, portion in self.targets:
                                if pct not in self._executed_parts:
                                    total_remaining += portion
                            
                            if total_remaining > 0.01:
                                self._execute_fraction(total_remaining, "sell")
                                self._record_trade("trailing_stop", price, total_remaining)
                            
                            return "trailing_stop"

                # ============ TARGETS ============
                for pct, portion in self.targets:
                    if pct in self._executed_parts: 
                        continue
                    
                    target = self.entry_price * (1 + pct / 100)
                    
                    if self.mode == "sell" and price >= target:
                        self._log("target_hit", 
                                 target_pct=pct,
                                 target_price=target,
                                 current_price=price,
                                 portion=portion,
                                 message=f"TARGET {pct}% ATINGIDO!")
                        
                        self._execute_fraction(portion, "sell")
                        self._record_trade(f"target_sell_{pct}%", price, portion)
                        self._executed_parts.append(pct)
                        
                        self._log("target_executed",
                                 executed_targets=len(self._executed_parts),
                                 total_targets=len(self.targets),
                                 remaining_targets=len(self.targets) - len(self._executed_parts))
                    
                    elif self.mode == "buy" and price <= target:
                        self._log("target_hit", 
                                 target_pct=pct,
                                 target_price=target,
                                 current_price=price,
                                 portion=portion,
                                 message=f"TARGET {pct}% ATINGIDO!")
                        
                        self._execute_fraction(portion, "buy")
                        self._record_trade(f"target_buy_{pct}%", price, portion)
                        self._executed_parts.append(pct)
                        
                        self._log("target_executed",
                                 executed_targets=len(self._executed_parts),
                                 total_targets=len(self.targets),
                                 remaining_targets=len(self.targets) - len(self._executed_parts))

                if not self._should_continue_cycle():
                    self._log("cycle_completed",
                             executed_targets=len(self._executed_parts),
                             total_targets=len(self.targets),
                             message="Ciclo completado com sucesso!")
                    return "completed"

                time.sleep(self.check_interval)
            
            return "completed"
            
        except Exception as e:
            self._log("cycle_error", 
                     error=str(e), 
                     error_type=type(e).__name__)
            return "error"

    def start(self):
        """Loop principal com auto-restart"""
        self._log("bot_started", 
                 message="Iniciando bot com suporte a múltiplos ciclos",
                 auto_restart=self.auto_restart,
                 max_cycles=self.max_cycles if self.max_cycles > 0 else "unlimited")
        
        try:
            while not self._stopped.is_set():
                # Executa um ciclo
                result = self._run_single_cycle()
                self._total_cycles_completed += 1
                
                self._log("cycle_finished",
                         cycle_number=self._current_cycle,
                         result=result,
                         total_cycles_completed=self._total_cycles_completed,
                         max_cycles=self.max_cycles if self.max_cycles > 0 else "unlimited")
                
                # Verifica se deve continuar
                if not self.auto_restart:
                    self._log("auto_restart_disabled",
                             message="Auto-restart desabilitado, finalizando bot")
                    break
                
                if self.max_cycles > 0 and self._total_cycles_completed >= self.max_cycles:
                    self._log("max_cycles_reached",
                             completed=self._total_cycles_completed,
                             max=self.max_cycles,
                             message="Número máximo de ciclos atingido")
                    break
                
                if result in ["stop_loss", "trailing_stop", "error"]:
                    self._log("restart_blocked",
                             reason=result,
                             message="Não reiniciando devido a condição de parada")
                    break
                
                # Aguarda antes de reiniciar
                restart_delay = 5
                self._log("restarting",
                         delay_seconds=restart_delay,
                         next_cycle=self._current_cycle + 1,
                         message=f"Reiniciando em {restart_delay}s...")
                
                time.sleep(restart_delay)
                
                # Reseta para novo ciclo
                self._reset_cycle()
                
        except KeyboardInterrupt:
            self._log("bot_interrupted", message="Interrompido pelo usuário")
        except Exception as e:
            self._log("bot_error", 
                     error=str(e), 
                     error_type=type(e).__name__)
            import traceback
            self._log("bot_traceback", traceback=traceback.format_exc())
        finally:
            self._finalize()

    def _finalize(self):
        """Finaliza e salva histórico completo"""
        total_profit = sum(
            sum(t.get("profit_usdt", 0) for t in cycle.get("trades", []))
            for cycle in self.all_cycles_history
        )
        
        # Adiciona ciclo atual se houver trades
        if self.executed_trades:
            current_cycle_profit = sum(t.get("profit_usdt", 0) for t in self.executed_trades)
            total_profit += current_cycle_profit
        
        self._log("bot_finalized",
                 total_cycles=self._total_cycles_completed,
                 total_profit_usdt=round(total_profit, 2),
                 duration_seconds=round(time.time() - self._start_ts, 1),
                 message="Bot finalizado - histórico completo salvo")
        
        final = {
            "id": self._id,
            "symbol": self.symbol,
            "mode": self.mode,
            "targets": self.targets,
            "auto_restart": self.auto_restart,
            "total_cycles_completed": self._total_cycles_completed,
            "cycles_history": self.all_cycles_history,
            "total_profit": total_profit,
            "dry_run": self.dry_run,
            "final_status": "completed",
            "end_ts": time.time()
        }
        _append_history(final)

    def stop(self):
        self._stopped.set()
        self._log("stop_requested", message="Solicitada parada do bot")

# ====================== CLI ======================
def parse_targets(s: str) -> List[Tuple[float, float]]:
    out = []
    for p in s.split(","):
        if ":" in p:
            try:
                a, b = p.split(":")
                out.append((float(a), float(b)))
            except:
                pass
    return out

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--symbol", default="BTC-USDT")
    p.add_argument("--entry", type=float, default=88000.0)
    p.add_argument("--mode", default="sell")
    p.add_argument("--targets", default="1:0.3,3:0.5,5:0.2")
    p.add_argument("--trailing", type=float, default=None)
    p.add_argument("--stoploss", type=float, default=None)
    p.add_argument("--size", type=float, default=0.001)
    p.add_argument("--funds", type=float, default=100.0)
    p.add_argument("--interval", type=float, default=5.0)
    p.add_argument("--dry", action="store_true", default=False)
    p.add_argument("--no-dry", dest="dry", action="store_false")
    p.add_argument("--verbose", action="store_true", default=False)
    p.add_argument("--auto-restart", action="store_true", default=False,
                   help="Reinicia automaticamente após completar todos os targets")
    p.add_argument("--max-cycles", type=int, default=0,
                   help="Número máximo de ciclos (0 = ilimitado)")
    args = p.parse_args()

    print(f"[START] Iniciando bot com:", file=sys.stderr, flush=True)
    print(f"  Symbol: {args.symbol}", file=sys.stderr, flush=True)
    print(f"  Entry: {args.entry}", file=sys.stderr, flush=True)
    print(f"  Targets: {args.targets}", file=sys.stderr, flush=True)
    print(f"  Auto-restart: {args.auto_restart}", file=sys.stderr, flush=True)
    print(f"  Max cycles: {args.max_cycles if args.max_cycles > 0 else 'unlimited'}", file=sys.stderr, flush=True)
    print(f"  Dry Run: {args.dry}", file=sys.stderr, flush=True)

    bot = EnhancedTradeBot(
        symbol=args.symbol,
        entry_price=args.entry,
        mode=args.mode,
        targets=parse_targets(args.targets),
        trailing_stop_pct=args.trailing,
        stop_loss_pct=args.stoploss,
        size=args.size,
        funds=args.funds,
        check_interval=args.interval,
        dry_run=args.dry,
        verbose=args.verbose,
        auto_restart=args.auto_restart,
        max_cycles=args.max_cycles
    )
    
    bot.start()
