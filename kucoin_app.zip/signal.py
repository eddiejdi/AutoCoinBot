# signal logic module
